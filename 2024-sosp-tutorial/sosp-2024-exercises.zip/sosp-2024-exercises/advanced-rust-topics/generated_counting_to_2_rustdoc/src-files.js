var srcIndex = new Map(JSON.parse('[\
["exercise_counting_to_2",["",[],["exercise_counting_to_2.rs"]]]\
]'));
createSrcSidebar();
